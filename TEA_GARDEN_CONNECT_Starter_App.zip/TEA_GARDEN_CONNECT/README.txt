TEA GARDEN CONNECT — Android-friendly starter prototype

WHAT IT DOES
- Mobile-first community directory with English, Assamese and Hindi interface labels.
- Sections: local jobs, village news, businesses, education, local products, cricket/sports.
- Add listing form; entries are saved in the browser's local storage on this device.
- Basic offline caching after first load when hosted over HTTPS.

IMPORTANT LIMITATIONS
- This is a front-end prototype, not a signed Android APK.
- Posts are stored only on the same device/browser; other people will not see them.
- No login, shared database, admin approval, verified jobs, chat, online payment or ad monetization.
- Demo listings are examples, not real offers. Verify all information before acting on it.

HOW TO TRY ON ANDROID
1. Extract this ZIP.
2. Upload the folder to a static HTTPS host (for example GitHub Pages or Netlify) or ask a developer to host it.
3. Open the hosted index.html link in Chrome on Android.
4. In Chrome menu, choose "Add to Home screen" or "Install app" if shown.

TO MAKE IT A REAL COMMUNITY APP
Add a secure backend/database, admin moderation, user reporting, privacy policy, consent, verified contact process and backups. Use a developer or a trusted adult for publishing and payment accounts.
